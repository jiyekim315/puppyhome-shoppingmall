/**
 * myscript.js
 */
alert('경고창을 띄웁니다.'); // ;은 해도 되고 안해도 된다.
window.alert("외부 자바스크립트 방식");