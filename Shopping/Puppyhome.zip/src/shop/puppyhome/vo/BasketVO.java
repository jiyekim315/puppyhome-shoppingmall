package shop.puppyhome.vo;

public class BasketVO {

}
