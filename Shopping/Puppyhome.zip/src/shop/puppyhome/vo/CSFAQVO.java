package shop.puppyhome.vo;

public class CSFAQVO {

	private String faq_title;
	private String faq_cont;
	private String faq_category;
	
	public String getFaq_title() {
		return faq_title;
	}
	public void setFaq_title(String faq_title) {
		this.faq_title = faq_title;
	}
	public String getFaq_cont() {
		return faq_cont;
	}
	public void setFaq_cont(String faq_cont) {
		this.faq_cont = faq_cont;
	}
	public String getFaq_category() {
		return faq_category;
	}
	public void setFaq_category(String faq_category) {
		this.faq_category = faq_category;
	}
	
	
}
