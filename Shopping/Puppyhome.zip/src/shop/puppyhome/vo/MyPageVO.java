package shop.puppyhome.vo;

public class MyPageVO {

}
